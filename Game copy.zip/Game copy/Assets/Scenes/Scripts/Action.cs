﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Action
{
    public string keyString;
    public string actionDescription;
    [TextArea]
    public string outcome;
    public Event nextEvent;

}
