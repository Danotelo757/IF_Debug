﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventNavigation : MonoBehaviour
{
    public Event presentEvent;
    Dictionary<string, Event> actionDictionary = new Dictionary<string, Event>();

    [HideInInspector] public Action action;

    GameController controller;

    private void Awake()
    {
        controller = GetComponent<GameController>();
    }

    public void ListPossibleActions()
    {
        for (int i = 0; i < presentEvent.actions.Length; i++)
        {
            actionDictionary.Add(presentEvent.actions[i].keyString, presentEvent.actions[i].nextEvent);
            controller.possibleEventActions.Add(presentEvent.actions[i].actionDescription);
        }
    }
    public void ClearActions()
    {
        actionDictionary.Clear();
    }
}